export interface Datos {
    nombre:string;
    pasaporte:string;
    telefono:number;
}